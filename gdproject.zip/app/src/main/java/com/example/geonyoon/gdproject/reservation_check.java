package com.example.geonyoon.gdproject;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

public class reservation_check extends Activity {
    Button rebutton;
    Button pop_Btn;
    Button close_Btn;

    LinearLayout pop_linear;
    LinearLayout login_Linear;
    View pop_View;

    PopupWindow popupWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_check);

        rebutton = (Button)findViewById(R.id.re_ch_btn);
        rebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(
                        getApplicationContext(),
                        MainActivity.class);
                startActivity(intent);
            }
        });

        // 팝업
        Resources lang_res = getResources();
        DisplayMetrics lang_dm = lang_res.getDisplayMetrics();
        int lang_width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 200, lang_dm);
        int lang_height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 300, lang_dm);
        login_Linear = (LinearLayout) findViewById(R.id.showpopup);
        pop_View = View.inflate(this, R.layout.popup2, null);
        popupWindow = new PopupWindow(pop_View, lang_width, lang_height, true);

        pop_Btn = (Button) findViewById(R.id.re_ch_can_btn);
        pop_Btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                popupWindow.showAtLocation(login_Linear, Gravity.CENTER, 0, 0);
            }
        });
        close_Btn = (Button) pop_View.findViewById(R.id.close_btn3);
        close_Btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                //intent.putExtra("select",sp1.getSelectedItem().toString());
                startActivity(intent);
            }
        });
    }
}

