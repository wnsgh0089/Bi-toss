package com.example.geonyoon.gdproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


public class reservation extends Activity {
    Button rebutton;
    Button button;
    ArrayAdapter<CharSequence> retalshop_array;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_rental);

        Spinner sp1 = (Spinner)findViewById(R.id.spin_retalshop);
        sp1.setPrompt("대여점을 선택해주세요.");

        retalshop_array = ArrayAdapter.createFromResource(this,R.array.select_retalshop,android.R.layout.simple_spinner_item);
        retalshop_array.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp1.setAdapter(retalshop_array);
        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        button = (Button)findViewById(R.id.retalshop_cancel);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        rebutton = (Button)findViewById(R.id.retalshop_next);
        rebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), reservation_other.class);
                startActivity(intent);
            }
        });
    }
}

