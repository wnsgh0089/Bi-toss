package com.example.geonyoon.gdproject;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.util.Calendar;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.TextView;
import android.widget.Toast;

import java.util.GregorianCalendar;

public class reservation_other extends Activity {
    int myear, mmonth, mday, mhour, mminute;
    TextView mtxtdate;
    TextView mtxttime;
    TextView mtxttime2;
    ArrayAdapter<CharSequence> adspin1;
    Button rebutton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_others);

        rebutton = (Button)findViewById(R.id.chocie_final);
        rebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Final_check.class);
                //intent.putExtra("select",sp1.getSelectedItem().toString());
                startActivity(intent);
            }
        });

        //텍스트뷰 2개 연결
        mtxtdate = (TextView)findViewById(R.id.daytxt);
        mtxttime = (TextView)findViewById(R.id.timetxt);

        //현재 날짜와 시간을 가져오기위한 Calender 인스턴스 선언
        Calendar cal = new GregorianCalendar();
        myear = cal.get(Calendar.YEAR);
        mmonth = cal.get(Calendar.MONTH);
        mday = cal.get(Calendar.DAY_OF_MONTH);
        mhour = cal.get(Calendar.HOUR_OF_DAY);
        mminute =cal.get(Calendar.MINUTE);

        UpdateNow();

        final RadioGroup rg = (RadioGroup)findViewById(R.id.RG_person);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int id = rg.getCheckedRadioButtonId();
                //getCheckedRadioButtonId() 의 리턴값은 선택된 RadioButton 의 id 값.
                RadioButton rb = (RadioButton) findViewById(id);
            }
        });

        Spinner sp2 = (Spinner)findViewById(R.id.bike);
        sp2.setPrompt("탑승할 인원을 선택하세요.");

        adspin1 = ArrayAdapter.createFromResource(this,R.array.select_bike,android.R.layout.simple_spinner_item);
            adspin1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp2.setAdapter(adspin1);
            sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    public void date_Click(View v) {
        switch(v.getId()){
            //날짜 대화상자 버튼이 눌리면 대화상자를 보여줌
            case R.id.btn_day:
                //리스너 등록
                new DatePickerDialog(reservation_other.this, mDateSetListener, myear,mmonth,mday).show();
                break;
            //시간 대화상자 버튼이 눌리면 대화상자를 보여줌
            case R.id.btn_time:
                new TimePickerDialog(reservation_other.this, mTimeSetListener,mhour,mminute,false).show();
                break;
        }
    }

    //날씨 대화상자 리스너 부분
    DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener(){
        public void onDateSet(DatePicker view, int year, int monthOfyear, int dayOfmonth){
            //사용자 값을 가져옴
            myear = year;
            mmonth = monthOfyear;
            mday = dayOfmonth;
            //텍스트뷰의 값을 업데이트 함
            UpdateNow();
        }
    };

    TimePickerDialog.OnTimeSetListener mTimeSetListener = new TimePickerDialog.OnTimeSetListener(){
        public void onTimeSet(TimePicker view, int hourOfday, int minute){
            //사용자 값을 가져옴
            mhour = hourOfday;
            mminute = minute;
            //텍스트뷰의 값을 업데이트 함
            UpdateNow();
        }
    };

    //텍스트뷰의 값을 업데이하는 메소드
    void UpdateNow(){
        mtxtdate.setText(String.format("%d/%d/%d",myear,mmonth+1,mday));
        mtxttime.setText(String.format("%d:%d",mhour,mminute));
    }
}